print("Hello")
print("World")
print("Hello",end=' ')
print("World")